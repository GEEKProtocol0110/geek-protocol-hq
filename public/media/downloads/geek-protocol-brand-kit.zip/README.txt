Geek Protocol artwork kit

Use these published assets to identify Geek Protocol in directory listings, articles and community resource pages. Keep their original proportions, colors and wording. A listing does not establish endorsement or a formal partnership.

geek-protocol-logo.png: 200 x 200 pixel PNG, original website logo.
geek-protocol-share.png: 1200 x 630 pixel PNG, promotional artwork.

Project website: https://www.geekprotocol.xyz/
Current facts: https://www.geekprotocol.xyz/about/
Media page: https://www.geekprotocol.xyz/media/
Current source: https://github.com/GEEKProtocol0110/geek-protocol-hq

Public Alpha. Career XP and Alpha credits are internal and nonwithdrawable. Public Mainnet treasury rewards are not live.
